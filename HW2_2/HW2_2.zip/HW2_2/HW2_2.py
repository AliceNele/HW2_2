# -*- coding: utf-8 -*-
"""
Created on Sun Mar 22 13:32:59 2020

@author: ASUS
"""
import pickle
import os



#class.py
class Customer:
    def __init__(self, name=str(), idnumber=str()):
        self.name = name #用戶姓名
        self.idnumber = idnumber #用戶身分證字號
        

class CreditCardAccount(Customer):
    def __init__(self, name=str(), idnumber=str(), credit=int()):
        Customer.__init__(self,name,idnumber)
        self.name = name #用戶姓名
        self.idnumber = idnumber #用戶身分證字號
        self.credit = credit #用戶人信用額度
        self.used = int(0)
        

    def create_user(self): # 選項 a 
        name = str(input("請輸入姓名: "))
        idnumber = str(input("請輸入身分證字號: "))
        if os.path.exists(file_list + "/" + idnumber+"_CreditCardAccount.pkl"):#先用身分證字號檢查是否已有可用帳戶
            print("已有可用帳戶")
        else: #沒有可用帳戶，繼續輸入信用額度
            credit = int(input("請輸入信用額度: "))
            data = CreditCardAccount(name, idnumber, credit) #把資料存到data裡面
            with open('./info/'+ idnumber +"_CreditCardAccount.pkl","wb") as info:
                pickle.dump(data, info)
                
    def consume(self,amount):
        if self.used + amount <= self.credit:
            self.used = self.used + amount
        else:
            print("無法新增消費，已超過信用額度")
    def getBalance(self):
        return self.limit - self.used
       
         
class BankAccount(Customer): #儲蓄存款，提款、存款
    def __init__(self, name=str(), idnumber=str(), password=str()):
        Customer.__init__(self,name,idnumber)
        self.name = name #用戶姓名
        self.idnumber = idnumber #用戶身分證字號
        self.password = password #用戶人密碼
        self.inmoney = 0
    
    def create_user(self): #選項 b
        name = str(input("請輸入姓名: "))
        idnumber = str(input("請輸入身分證字號: "))
        if os.path.exists(file_list + "/" + idnumber+"_BankAccount.pkl"):
             print("已有可用帳戶")                    
        else: #沒有可用帳戶，繼續輸入密碼
            BankAccount.get_password(self)
            
            data = BankAccount(name, idnumber, self.password)
            with open('./info/'+idnumber+'_BankAccount.pkl','wb') as info:
                pickle.dump(data, info)
    def get_password(self): # 輸入密碼
        while True:
            self.password = str(input("請輸入密碼: "))
            if self.check_password(self.password):
               
                break
            else:
                print("密碼不符合規定，請重新輸入")
        return self.password

    def check_password(self,password): # 檢查密碼
        if len(self.password) < 6 or len(self.password) >20:
            return False
        
        flag_num = False
        flag_big = False
        flag_small = False
        for i in password:
            if 48 <= ord(i) and ord(i) <= 57: # 檢查是否至少有一個數字
                flag_num = True
            elif 65 <= ord(i) and ord(i) <= 90: # 檢查是否有至少一個英文大寫
                flag_big = True
            elif 97 <= ord(i) and ord(i) <= 122: # 檢查是否有至少一個英文小寫
                flag_small = True
        if flag_num and flag_big and flag_small:
            return True
        else:
            return False
                    
    def askpassword(self): #(3)查詢儲蓄存款帳戶密碼
        print("密碼為: %s" %(self.password))
    
    def askbalance(self): #(4)查詢儲蓄存款帳戶餘額
        print("餘額為: %s" % (self.inmoney - self.outmoney))
        
    def save_money(self): #(5)存款
        self.inmoney += save_money
        print("餘額為: %s" %(self.inmoney))
      
    def withdraw(self):  #(6)提款
        if self.inmoney >= take_money:
            self.inmoney -= take_money
            print("餘額為: %s" %(self.inmoney))
        
        else: # 跟他說都不夠額度了還敢花錢啊
            print("沒那麼多錢還改提這麼多啊")
 
    
       
       

#==================================
#main

#from  ...import... 
creditaccount = CreditCardAccount(Customer)
bankaccount = BankAccount(Customer)
file_list = os.path.join(os.getcwd(),'info') #info 的位置

choice = str(input("(a) 新增信用卡帳戶 (b) 新增儲蓄存款帳戶 (c) 更新或查詢帳戶情況: "))
if choice == "a": 
    creditaccount.create_user() #回去執行 CreditCardAccount 的 create_user
    

elif choice == "b":
    bankaccount.create_user() #回去執行 BankAccount 的 create_user
    
elif choice == "c":
    idnumber = input("請輸入身分證字號: ")
    print("(1) 查詢信用卡可用餘額 ")
    print("(2)新增信用卡消費金額")
    print("(3)查詢儲蓄存款帳戶密碼")
    print("(4)查詢儲蓄存款帳戶餘額")
    print("(5)存款")
    print("(6)提款")
    option = input("請選擇欲執行之功能： ")
    if option == "1" or option == "2": # 信用卡功能
        
        if os.path.exists(file_list + "/" + idnumber+"_CreditCardAccount.pkl"): # 確認此 id 已有開過帳
            if option == "1": #查詢信用卡可用餘額
                with open('./info/'+idnumber + '_CreditCardAccount.pkl','rb') as info:
                    account = pickle.load(info)
                balance = account.getBalance()
                print(balance)
            elif option == "2": #新增信用卡消費金額
                with open('./info/'+idnumber + '_CreditCardAccount.pkl','rb') as info:
                    account = pickle.load(info)
                amount = int(input("請輸入消費金額: "))
                account.consume(account)
                 
        else: 
            print("請先開立帳戶")
            creditaccount.create_user()
            
    if option == "3" or option == "4" or option == "5" or option == "6":
        #file_list = os.listdir('info')
        if  os.path.exists(file_list + "/" + idnumber+"_BankAccount.pkl"): # 確認此 id 已有開過帳戶
            if option == "3": #查詢儲蓄存款帳戶密碼
                with open('./info/'+idnumber + '_BankAccount.pkl','rb') as info:
                    user = pickle.load(info)
                bankaccount.askpassword()
            elif option == "4": #查詢儲蓄存款帳戶餘額
                with open('./info/'+idnumber + '_BankAccount.pkl','rb') as info:
                    user = pickle.load(info)
                bankaccount.askbalance()
            elif option == "5": #存款
                with open('./info/'+idnumber + '_BankAccount.pkl','rb') as info:
                    user = pickle.load(info)
                save_money = int(input("請輸入存入金額: "))
                bankaccount.save_money()
                bankaccount.askbalance()
            elif option == "6": # 提款
                with open('./info/'+idnumber + '_BankAccount.pkl','rb') as info:
                    user = pickle.load(info)
                take_money = int(input("請輸入提出金額: "))
                bankaccount.withdraw()
            
        else: 
            print("請先開立帳戶")
            bankaccount.create_user()
            
                    
#c
